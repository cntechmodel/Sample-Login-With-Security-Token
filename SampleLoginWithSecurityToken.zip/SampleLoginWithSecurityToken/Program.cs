﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace SampleLoginWithSecurityToken
{
    class Program
    {
        [DllImport("dmscli.dll", CharSet = CharSet.Unicode)]
        private static extern bool aaApi_LoginWithSecurityToken(string dataSource, string securityToken, bool asAdmin, string hostname, long[] productIds);

        private static string DatasourceName;

        private static void GetApplicationDefaultProperties()
        {
            // edit the .config file or use command line arguments 
            DatasourceName = Properties.Settings.Default.DatasourceName.Trim();
        }

        private static void GetUserSpecifiedValuesFromCommandLine(string[] args)
        {
            bool ShowUsageMessage = false;

            for (var argIndex = 0; argIndex < args.Length; argIndex++)
                if (args[argIndex].ToLower() == "-d")
                {
                    DatasourceName = args[++argIndex];
                }
                else if (args[argIndex].ToLower() == "-?")
                {
                    ShowUsageMessage = true;
                }
                else
                {
                    ShowUsageMessage = true;
                    Console.WriteLine("[Error  ] Invalid command line argument '{0}'", args[argIndex]);
                }

            if (ShowUsageMessage)
                ShowUsageAndExit();
        }

        public static void ShowPWError()
        {
            Console.WriteLine("[{0}]\n{1}\n{2}",
                    PWWrapper.aaApi_GetLastErrorId(),
                    PWWrapper.aaApi_GetLastErrorMessage(),
                    PWWrapper.aaApi_GetLastErrorDetail());
        }

        public static void ShowUsageAndExit()
        {
            Console.WriteLine("");
            Console.WriteLine("======");
            Console.WriteLine("Usage:");
            Console.WriteLine("======");
            Console.WriteLine("{0} [-d Server:DSName]", Process.GetCurrentProcess().ProcessName);
            Console.WriteLine("------");
            Console.WriteLine("Notes:");
            Console.WriteLine("------");
            Console.WriteLine("Command line argument override the value in {0}.config.", Process.GetCurrentProcess().ProcessName);
            Console.WriteLine("");

            ExitApp(-1);
        }

        public static void ExitApp(int exitCode)
        {
            // When in the debugger, the console window will stay open.
            if (Debugger.IsAttached)
            {
                Console.Write("Press any key to exit console window when in debug mode...");
                Console.ReadKey();
            }

            PWWrapper.aaApi_Uninitialize(); // good practice as it will free up some local resources
            Environment.Exit(exitCode);
        }

        static void Main(string[] args)
        {
            // Get default datasource and possible command line override.
            GetApplicationDefaultProperties();
            GetUserSpecifiedValuesFromCommandLine(args);

            // Before we login, we can check to see what version of ProjectWise are we using.
            // This will be the version of ProjectWise Explorer on this machine.
            int majorHigh = 0;
            int majorLow = 0;
            int minorVersion = 0;
            int buildNo = 0;

            if (!PWWrapper.aaApi_GetAPIVersion(ref majorHigh, ref majorLow, ref minorVersion, ref buildNo))
            {
                // Good practice to check if an API call was successful or not
                ShowPWError();
                ExitApp(-2);
            }
            else
            {
                Console.WriteLine("ProjectWise Explorer Version {0}.{1}.{2}.{3} installed.", majorHigh, majorLow, minorVersion, buildNo);
            }

            // parse the command line argument
            string serverName = DatasourceName.Split(':')[0];
            string loginToken = "";

            try
            {
                // Try to contact the Connection Client and ask for the login token.
                try
                {
                    Console.WriteLine("Attempting to obtain token from CONNECTION Client...");
                    loginToken = ConnectionClientToken.GetLoginToken(DatasourceName);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    ExitApp(-1);
                }

                Console.WriteLine("Successfully obtained token from CONNECTION Client");
                if (string.IsNullOrEmpty(loginToken))
                {
                    // empty token - Connection client not installed?
                    Console.WriteLine("However, the token is empty.");
                    Console.WriteLine($"\tVerify that the Datasource '{DatasourceName}' specified is valid.");
                    Console.WriteLine("\tVerify that ProjectWise CONNECTION Client is installed, configured and signed in.");
                    ExitApp(-1);
                }

                Console.WriteLine($"Attempting to log in to '{DatasourceName}' using Bentley IMS...");
                if (!aaApi_LoginWithSecurityToken(DatasourceName, loginToken, false, null, null))
                {
                    Console.WriteLine($"Error logging in to '{DatasourceName} ' using Bentley IMS.");
                    ShowPWError();
                    ExitApp(-1);
                }

                // do something...
                String CurrentUsername = string.Empty;

                CurrentUsername = PWWrapper.GetUserName(PWWrapper.aaApi_GetCurrentUserId());

                Console.WriteLine($"Successfully logged in to '{DatasourceName}' using Bentley IMS for user '{CurrentUsername}'.");

                // ToDo: Add your code here...

                // logout - good practice as it will free up some resources on the server
                if (!PWWrapper.aaApi_LogoutByHandle(PWWrapper.aaApi_GetActiveDatasource()))
                {
                    Console.WriteLine($"Error logging out of '{DatasourceName}'.");
                    ShowPWError();
                    ExitApp(-1);
                }
                else
                {
                    Console.WriteLine($"Successfully logged out of '{DatasourceName}'.");
                }

            } // try 
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                ExitApp(-1);
            }

            ExitApp(0);
        }
    }
}
